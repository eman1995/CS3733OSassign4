#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<time.h>

typedef struct arrays {
	double * sub1;
	double * sub2;
} arrays;

double * mainarrayA;
double * mainarrayB;
double * mainarrayC;
int size;
//bubble sort implemented
void sort(double array[], int arrsize) {
	int i, j, temp;
	for(i=0; i<arrsize-1; i++) {
		for(j=0; j<arrsize-i-1; j++) {
			if(array[j] > array[j+1]) {
				temp = array[j];
				array[j] = array[j+1];
				array[j+1] = temp;
			}
		}
	}
}

void *threadB(void *args) {
    sort(mainarrayB, size); //simply calls sort and then returns
    return NULL;
}

void *threadA1(void *args) {
    arrays *temp = (arrays *)args; //calls sort on one half of mainarrayA
    sort(temp->sub1, size/2 + 1);
    return NULL;
}

void *threadA2(void *args) {
    arrays *temp = (arrays *)args; //same as A1 but on second half
    sort(temp->sub2, size/2 +1);
    return NULL;
}
//compares both arrays in struct with each other, the smaller elements are put on mainarrayC and then the respective array's position is incremented by one
void *mergeThread(void *args) { 
    arrays *temp = (arrays *)args;
    int i, j=0, k=0;
    for(i=0; i<size; i++) {
        if(temp->sub1[j] < temp->sub2[k]) { 
            mainarrayC[i] = temp->sub1[j++];
        }
        else if(temp->sub1[j] > temp->sub2[k]) { 
            mainarrayC[i] = temp->sub2[k++];
        }
        else {
            mainarrayC[i] = temp->sub1[j++];
        }    
    }
    return NULL;
}

void fillarray() {
	mainarrayA = malloc(size * sizeof(double));
	mainarrayB = malloc(size * sizeof(double));
	mainarrayC = malloc(size * sizeof(double)); //all 3 arrays are globals and malloc
	time_t t;
	int i;
	srand((unsigned) time(&t));
	
	for(i=0; i<size; i++) mainarrayA[i] = rand() % 100 + 1; //fill mainarrayA with random doubles
	for(i=0; i<size; i++) mainarrayB[i] = mainarrayA[i]; //array A is copied into B at the same time
}

void copyarray(arrays *array) {
    //array.sub1 = malloc(((size/2) + 1) * sizeof(double));
    //array.sub2 = malloc(((size/2) + 1) * sizeof(double));
    int i;
    for(i=0; i<size/2; i++) { 
        array->sub1[i] = mainarrayA[i];
        //printf("%.1f\n", array.sub1[i]);
    }
    for(i=size/2; i<size; i++) {
        array->sub2[i] = mainarrayA[i];
       //printf("%.1f\n", array.sub2[i]);
    }
    //printf("%d\n", size/2);
}

int main(int argc, char *argv[]) {
	size = atoi(argv[1]); //get size from cmd line
    arrays arr; //declare struct
	pthread_t  thB, thA1, thA2, thM; //declare all threads to be used
	clock_t start_t, end_t; //clock 
    double duration;
    
    arr.sub1 = malloc((size/2 + 1) * sizeof(double));
    arr.sub2 = malloc((size/2 + 1) * sizeof(double));
    //init the arrays inside struct with proper sizes
    fillarray(); //fill main array and init all 3 arrays with proper size
	//fine
	start_t = clock();
	pthread_create(&thB, NULL, threadB, (void *)&arr); //thread is passed the struct unknown how to keep field empty
	pthread_join(thB, NULL); //thread is joined
	end_t = clock();
    
    duration = (double)(end_t - start_t) / CLOCKS_PER_SEC;
	printf("Sorting is done in %.1fms when one thread is used\n", duration); 
    //display the timming of thread
    copyarray(&arr); //mainthread A is
    
    start_t = clock();
    pthread_create(&thA1, NULL, threadA1, (void *)&arr);
    pthread_create(&thA2, NULL, threadA2, (void *)&arr); //multithreads created
    pthread_join(thA1, NULL); //joined to work in sync
    pthread_join(thA2, NULL);
    pthread_create(&thM, NULL, mergeThread, (void *)&arr); //third thread created to merge results into arrayC
    pthread_join(thM, NULL);
    end_t = clock();

    duration = (double)(end_t - start_t) / CLOCKS_PER_SEC;
    printf("Sorting is done in %.1fms when two threads are used\n", duration);
    //timming of all three threads printed
	return 0;
}
